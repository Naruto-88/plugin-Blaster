=== NetStripes Update Monitor ===
Contributors: netstripes
Requires at least: 6.6
Tested up to: 6.6
Stable tag: 0.1.0
Requires PHP: 8.1
License: GPLv2 or later

Provides secure endpoints to report core and plugin update status to the dashboard.

